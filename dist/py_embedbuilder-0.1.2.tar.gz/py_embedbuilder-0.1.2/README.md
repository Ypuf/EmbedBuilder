does a lot of shit and simplifies discord's annoying and lengthy embed creation process.
